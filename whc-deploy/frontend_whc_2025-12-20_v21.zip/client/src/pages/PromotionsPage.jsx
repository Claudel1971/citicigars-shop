import React, { useState, useEffect } from 'react';
import { useProducts } from '@/context/ProductContext';
import ProductCard from '@/components/catalogue/ProductCard';
import ProductDetail from '@/components/catalogue/ProductDetail';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import CartDrawer from '@/components/cart/CartDrawer';
import { Tag } from 'lucide-react';
import i18n from '@/i18n';

export default function PromotionsPage() {
  const { products } = useProducts();
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [, setLang] = useState(i18n.language);

  useEffect(() => {
    const handleLangChange = (lng) => setLang(lng);
    i18n.on('languageChanged', handleLangChange);
    return () => i18n.off('languageChanged', handleLangChange);
  }, []);

  const t = (key) => i18n.t(key);

  const promos = React.useMemo(() => {
    return products.filter(p => {
      // Exclure les produits masqués
      if (p.inCatalogue === false) return false;
      
      const unitPromo = p.promotions?.unitaire;
      const packPromo = p.promotions?.pack;
      const boitePromo = p.promotions?.boite;
      const bundlePromo = p.promotions?.bundle;
      
      const hasUnitDiscount = unitPromo?.actif && unitPromo?.pourcentage > 0;
      const hasPackDiscount = packPromo?.actif && packPromo?.pourcentage > 0;
      const hasBoiteDiscount = boitePromo?.actif && boitePromo?.pourcentage > 0;
      const hasBundleDiscount = bundlePromo?.actif && bundlePromo?.pourcentage > 0;
      
      return hasUnitDiscount || hasPackDiscount || hasBoiteDiscount || hasBundleDiscount;
    });
  }, [products]);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />
      <main className="flex-1">
        {/* Hero Section */}
        <div className="bg-destructive text-white py-12">
            <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 flex justify-center items-center gap-3">
                <Tag size={40} /> {t('promotions.title')}
            </h1>
            <p className="text-xl opacity-90">
                {t('promotions.subtitle')}
            </p>
            </div>
        </div>
        
        <div className="container mx-auto px-4 py-8">
            {promos.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {promos.map(product => (
                    <ProductCard 
                        key={product.sku} 
                        product={product} 
                        onOpenDetails={setSelectedProduct}
                    />
                ))}
                </div>
            ) : (
                <div className="text-center py-20">
                    <p className="text-xl text-muted-foreground">{t('promotions.noPromos')}</p>
                </div>
            )}
        </div>
      </main>
      <Footer />
      <CartDrawer />
      <ProductDetail 
        product={selectedProduct} 
        isOpen={!!selectedProduct} 
        onClose={() => setSelectedProduct(null)} 
      />
    </div>
  );
}
